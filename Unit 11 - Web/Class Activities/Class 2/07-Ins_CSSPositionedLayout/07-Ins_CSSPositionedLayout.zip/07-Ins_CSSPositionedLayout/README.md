# Instructor Demo

* After completing the PowerPoint slides on CSS Positioning, begin live coding based on this [live-coding example](Solved/main.html).

  * If you are running low on time, it is more important to go over the positioning examples than it is to go through the slides themselves.

  * When going through the examples one-by-one, make sure to have the inspector open in Google Chrome so that we can show the class the differences between one form of CSS positioning and another both on the page and in the code.

  * If you have time, this would be a good opportunity to ask your students what they feel are the advantages and disadvantages of each form of positioning.
